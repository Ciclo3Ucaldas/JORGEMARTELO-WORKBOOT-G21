using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace TallerMintic.App.Dominio.Entidades
{
    public class Cliente : Persona
    {
        public int IdCliente { get; set; }
    }
}