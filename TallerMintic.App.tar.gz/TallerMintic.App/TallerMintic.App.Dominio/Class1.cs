﻿using System;

namespace TallerMintic.App.Dominio
{
    public class Class1
    {

    }
}
