﻿using System;

namespace TallerMintic.App.Persistencia
{
    public class Class1
    {

    }
}
